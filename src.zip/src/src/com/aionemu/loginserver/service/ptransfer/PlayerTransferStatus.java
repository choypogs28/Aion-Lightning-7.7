package com.aionemu.loginserver.service.ptransfer;

/**
 * @author KID
 */
public enum PlayerTransferStatus {
	STEP1,
	STEP2, 
	STEP1_OK, 
	STEP2_OK
}
