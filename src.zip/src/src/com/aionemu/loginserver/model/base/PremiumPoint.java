package com.aionemu.loginserver.model.base;

/**
 * @author KID
 */
public class PremiumPoint {

	public long current, updated;
}
