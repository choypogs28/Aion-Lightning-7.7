package com.aionemu.loginserver.dao;

import com.aionemu.commons.database.dao.DAO;

/**
 * @author KID
 */
public abstract class PremiumDAO implements DAO {

	public abstract long getToll(int accountId);
	public abstract long getLuna(int accountId);

	public abstract boolean updateToll(int accountId, long toll, long required);
	
	public abstract boolean updateLuna(int accountId, long luna, long required);
	
	@Override
	public final String getClassName() {
		return PremiumDAO.class.getName();
	}
}
