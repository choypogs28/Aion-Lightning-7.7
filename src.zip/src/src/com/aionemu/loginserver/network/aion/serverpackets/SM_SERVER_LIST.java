package com.aionemu.loginserver.network.aion.serverpackets;

import java.util.Collection;
import java.util.Map;

import com.aionemu.loginserver.GameServerInfo;
import com.aionemu.loginserver.GameServerTable;
import com.aionemu.loginserver.controller.AccountController;
import com.aionemu.loginserver.network.aion.AionServerPacket;
import com.aionemu.loginserver.network.aion.LoginConnection;

public class SM_SERVER_LIST extends AionServerPacket
{
	public SM_SERVER_LIST() {
		super(0x04);
	}
	
	@Override
	protected void writeImpl(LoginConnection con) {
		Collection<GameServerInfo> servers = GameServerTable.getGameServers();
		Map<Integer, Integer> charactersCountOnServer = null;
		int accountId = con.getAccount().getId();
		int maxId = 0;
		charactersCountOnServer = AccountController.getGSCharacterCountsFor(accountId);
		writeC(servers.size());
		writeC(con.getAccount().getLastServer());
		for (GameServerInfo gsi: servers) {
			if (gsi.getId() > maxId) {
				maxId = gsi.getId();
			}
			writeC(gsi.getId());
			writeB(gsi.getIPAddressForPlayer(con.getIP()));
			writeD(gsi.getPort());
			writeC(0x00);
			writeC(0x01);
			writeH(gsi.getCurrentPlayers());
			writeH(gsi.getMaxPlayers());
			writeC(gsi.isOnline() ? 1 : 0);
			switch (gsi.getId()) {
				case 70:
				case 75:
				case 76: //Master Server.
				case 80: //PTS Server.
					writeD(1025);
				break;
				case 100:
					writeD(4);
				break;
				default:
					writeD(1);
				break;	
			}
			writeC(0);
		}
		writeH(maxId + 1);
		writeC(0x01);
		for (int i = 1; i <= maxId; i++) {
			if (charactersCountOnServer.containsKey(i)) {
				writeC(charactersCountOnServer.get(i));
			} else {
				writeC(0);
			}
		}
	}
}